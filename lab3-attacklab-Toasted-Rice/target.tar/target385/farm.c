/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_204(unsigned *p)
{
    *p = 2428995914U;
}

unsigned addval_460(unsigned x)
{
    return x + 2425387096U;
}

unsigned getval_391()
{
    return 3243782876U;
}

unsigned addval_289(unsigned x)
{
    return x + 2496104776U;
}

unsigned getval_479()
{
    return 2421687083U;
}

void setval_342(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_353(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_465(unsigned x)
{
    return x + 2076414040U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_494(unsigned *p)
{
    *p = 2428684664U;
}

void setval_270(unsigned *p)
{
    *p = 1505874313U;
}

unsigned addval_396(unsigned x)
{
    return x + 3285096899U;
}

unsigned addval_200(unsigned x)
{
    return x + 3523793289U;
}

unsigned getval_419()
{
    return 3251734989U;
}

unsigned addval_151(unsigned x)
{
    return x + 2430634314U;
}

void setval_422(unsigned *p)
{
    *p = 3675836041U;
}

unsigned getval_469()
{
    return 3269495112U;
}

void setval_434(unsigned *p)
{
    *p = 2430642504U;
}

unsigned addval_209(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_331()
{
    return 3281047937U;
}

void setval_155(unsigned *p)
{
    *p = 2496760204U;
}

unsigned addval_439(unsigned x)
{
    return x + 3523789449U;
}

unsigned addval_473(unsigned x)
{
    return x + 3263740868U;
}

void setval_235(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_328()
{
    return 3281047169U;
}

unsigned getval_314()
{
    return 3381973385U;
}

unsigned addval_138(unsigned x)
{
    return x + 2430601544U;
}

unsigned addval_168(unsigned x)
{
    return x + 3372797577U;
}

void setval_164(unsigned *p)
{
    *p = 3380923913U;
}

unsigned getval_220()
{
    return 3767093866U;
}

unsigned getval_495()
{
    return 3374371209U;
}

unsigned getval_415()
{
    return 2425668233U;
}

unsigned addval_372(unsigned x)
{
    return x + 3529556617U;
}

void setval_258(unsigned *p)
{
    *p = 3373843081U;
}

void setval_410(unsigned *p)
{
    *p = 3263778161U;
}

void setval_461(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_386()
{
    return 3372798217U;
}

unsigned getval_214()
{
    return 3286272328U;
}

unsigned getval_315()
{
    return 3374894729U;
}

unsigned addval_245(unsigned x)
{
    return x + 3374894729U;
}

unsigned addval_299(unsigned x)
{
    return x + 3224945321U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
